const express = require('express');
const mysql = require('mysql');
const app = express();
app.use(express.json())
app.use((request,response,next)=>{
    response.setHeader("Access-Control-Allow-Origin","*")
    response.setHeader("Access-Control-Allow-Headers","*")
    response.setHeader("Access-Control-Allow-Methods","*")
    next();
})
app.get("/users",(request,response)=>{
    debugger;
    
     var connection=mysql.createConnection({
                                            host:'localhost',
                                            user:'root',
                                            password:'root',
                                            database:'ali'
                                        });
connection.query("select * from users",(error,result)=>{
    debugger;
       if(error==null)
       {
        response.setHeader("content-type","application/json");
           var data=JSON.stringify(result);
           connection.end();
           response.send(data);
           
           
       }
       else
       {
           response.setHeader("content-type","application/json");
           connection.end();
           response.send("some error occured");
       }
    })
})

app.get("/users/:id",(request,response)=>{
    debugger;
    console.log("inside get");
     var connection=mysql.createConnection({
                                            host:'localhost',
                                            user:'root',
                                            password:'root',
                                            database:'ali'
                                        });
var statement=`select * from users where id=${request.params.id}`;
connection.query(statement,(error,result)=>{
    debugger;
       if(error==null)
       {
        response.setHeader("content-type","application/json");
           var data=JSON.stringify(result);
           connection.end();
           response.send(data);
           
           
       }
       else
       {
           response.setHeader("content-type","application/json");
           connection.end();
           response.send("some error occured");
       }
})
});
app.post("/users",(request,response)=>{
    
    //console.log(request.body);
   

    var connection=mysql.createConnection({
        host:'localhost',
        user:'root',
        password:'root',
        database:'ali'
    });
   var statment=`insert into users values(
                 ${request.body.id},
               '${request.body.name}',
               ${request.body.salary}
               )`;
     connection.query(statment,(error,result)=>{
                if(error==null)
                {
                    response.setHeader("content-type","application/json");
                    var data=JSON.stringify(result);
                    connection.end();
                    response.send(data);
                }
                else{
                    response.setHeader("content-type","application/json");
                    var data=JSON.parse(error);
                    connection.end();
                    response.send(data);
                }
               })
   
   

})
app.put("/users/:id",(request,response)=>{
    
    //console.log(request.body);
   

    var connection=mysql.createConnection({
        host:'localhost',
        user:'root',
        password:'root',
        database:'ali'
    });
   var statment=`update users set
   id=${request.body.id}
   name='${request.body.name}',
   salary=${request.body.salary}
    where id=${request.params.id}`;
                  
     connection.query(statment,(error,result)=>{
                if(error==null)
                {
                    response.setHeader("content-type","application/json");
                    var data=JSON.stringify(result);
                    connection.end();
                    response.send(data);
                }
                else{
                    response.setHeader("content-type","application/json");
                    var err=JSON.stringify(error);
                    connection.end();
                    response.send(err);
                }
               })
   
   

})
app.delete("/users/:id",(request,response)=>{
    
    //console.log(request.body);
   

    var connection=mysql.createConnection({
        host:'localhost',
        user:'root',
        password:'root',
        database:'ali'
    });
   var statment=`delete from users
                  where id=${request.params.id}`;
     connection.query(statment,(error,result)=>{
                if(error==null)
                {
                    response.setHeader("content-type","application/json");
                    var data=JSON.stringify(result);
                    connection.end();
                    response.send(data);
                }
                else{
                    response.setHeader("content-type","application/json");
                    var data=JSON.parse(error);
                    connection.end();
                    response.send(data);
                }
               })
   
   

})
app.listen(9887,()=>{console.log("server is started at port 9887....")})